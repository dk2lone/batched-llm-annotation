# Camera-ready source: SP19293

When LLM Labels Fail Together, IEEE BigData 2026 High School Symposium.

Compile with:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

Or use Tectonic:

    tectonic -X compile main.tex

The source uses IEEEtran, newtx, and the packages declared in main.tex.
All required figures, generated tables, and bibliography entries are included.
The expected output is five US Letter pages, including references.

The CSVs and provenance.json preserve the numerical sources behind the tables.
This source package does not contain the research execution tree.
IEEE PDF eXpress validation and submission remain separate steps.
